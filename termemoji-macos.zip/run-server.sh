#!/bin/bash
echo "Starting TermEmoji Server..."
./termemoji-server --host 0.0.0.0 --port 8765
