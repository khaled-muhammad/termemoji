#!/bin/bash
echo "Starting TermEmoji Game..."
./termemoji
